<div class="container-fluid h-100 pageloader">
    <div class="row h-100">
        <div class="col-12 align-self-center">
            <figure class=" logo-landing mb-4 mx-auto">
                <img style="width:100px" src="wp-content/img/Logo-Small-PG.svg" alt="">
            </figure>
            <h2 class="text-uppercase font-weight-medium text-white">Planet Gadgets</h2>
            <p class="text-white text-mute">Online Shopping</p>
            <br>
            <div class="spinner-border text-light" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
    </div>
</div>